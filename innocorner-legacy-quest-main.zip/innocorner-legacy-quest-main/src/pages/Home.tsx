import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Layout from "@/components/Layout";

const Home = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Welcome to Our Platform
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Discover innovative solutions for your business needs
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/products">
              <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white">
                Explore Products
              </Button>
            </Link>
            <Button variant="outline" size="lg">
              Our Services
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4 bg-muted/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-blue-600">
            Our Services
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Service cards would go here - placeholder for now */}
            <div className="text-center">
              <p className="text-muted-foreground">Loading services...</p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">
            Why Choose Us
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4 text-foreground">Quality Service</h3>
                <p className="text-muted-foreground mb-4">
                  We deliver exceptional quality in everything we do
                </p>
                <Link to="/products">
                  <Button variant="link" className="text-orange-500 hover:text-orange-600">
                    View Products →
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4 text-foreground">Expert Team</h3>
                <p className="text-muted-foreground mb-4">
                  Our experienced team is here to support you
                </p>
                <Link to="/about">
                  <Button variant="link" className="text-orange-500 hover:text-orange-600">
                    Learn More →
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4 text-foreground">Customer Focus</h3>
                <p className="text-muted-foreground mb-4">
                  Your success is our priority
                </p>
                <Link to="/contact">
                  <Button variant="link" className="text-orange-500 hover:text-orange-600">
                    Contact Us →
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Home;