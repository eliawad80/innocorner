import Layout from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";

const About = () => {
  return (
    <Layout>
      <div className="container mx-auto py-12 px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">About InnoCorner</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Learn about our mission, vision, and the expert team behind our platform
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="mb-8">
            <CardContent className="pt-6">
              <h2 className="text-2xl font-semibold mb-4 text-blue-600">Our Mission</h2>
              <p className="text-muted-foreground leading-relaxed">
                At InnoCorner, we are dedicated to providing innovative solutions that help businesses 
                thrive in today's competitive landscape. Our platform connects creativity with technology 
                to deliver exceptional results for our clients.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardContent className="pt-6">
              <h2 className="text-2xl font-semibold mb-4 text-blue-600">Our Vision</h2>
              <p className="text-muted-foreground leading-relaxed">
                We envision a world where every business has access to cutting-edge tools and expert 
                guidance to unlock their full potential. Through our platform, we aim to democratize 
                innovation and make advanced business solutions accessible to all.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h2 className="text-2xl font-semibold mb-4 text-blue-600">Our Expert Team</h2>
              <p className="text-muted-foreground leading-relaxed">
                Our experienced team brings together diverse expertise in technology, business strategy, 
                and customer success. We are passionate about helping our clients achieve their goals 
                and are committed to providing the highest level of service and support.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default About;