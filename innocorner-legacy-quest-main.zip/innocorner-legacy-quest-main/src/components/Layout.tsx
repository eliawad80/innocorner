import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";

const Layout = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <nav className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">IC</span>
              </div>
              <span className="font-semibold text-foreground">InnoCorner</span>
            </Link>
            
            <div className="hidden md:flex items-center space-x-6">
              <Link 
                to="/" 
                className={`text-sm transition-colors hover:text-primary ${
                  isActive('/') ? 'text-primary font-medium' : 'text-muted-foreground'
                }`}
              >
                Home
              </Link>
              <Link 
                to="/products" 
                className={`text-sm transition-colors hover:text-primary ${
                  isActive('/products') ? 'text-primary font-medium' : 'text-muted-foreground'
                }`}
              >
                Products
              </Link>
              <Link 
                to="/about" 
                className={`text-sm transition-colors hover:text-primary ${
                  isActive('/about') ? 'text-primary font-medium' : 'text-muted-foreground'
                }`}
              >
                About
              </Link>
              <Link 
                to="/contact" 
                className={`text-sm transition-colors hover:text-primary ${
                  isActive('/contact') ? 'text-primary font-medium' : 'text-muted-foreground'
                }`}
              >
                Contact
              </Link>
              <Link to="/login">
                <Button variant="outline" size="sm">Login</Button>
              </Link>
            </div>
          </nav>
        </div>
      </header>
      
      <main>{children}</main>
    </div>
  );
};

export default Layout;